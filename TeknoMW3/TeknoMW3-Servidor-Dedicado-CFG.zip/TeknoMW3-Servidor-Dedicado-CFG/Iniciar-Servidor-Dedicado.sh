#!/bin/bash


# Nombre del Servidor
# Solo como información, no afecta a la ventana ni el nombre de tu servidor. :c!
export NombreServidor="[TG] TeknoGods"


# Visibilidad del Servidor
# 1 - Servidor Dedicado LAN
# 2 - Servidor Dedicado Internet
export VisibilidadServidor="2"


# IP del Servidor
# IPv4 Interna que usará el Servidor.
# Por defecto: localhost
export GameIP="localhost"


# Puerto Seguro de Juego
# - Valores desde 0 hasta 65535
#   * Asegúrese de Abrir el Puerto en UDP y TCP!
export PuertoServidor="27016"


# Puerto del Servidor Maestro (Explorador de Servidores)
# - Valores desde 0 hasta 65535
#   * Asegúrese de Abrir el Puerto en UDP y TCP!
#     * Si su valor no es el predeterminado, es posible que no vea el servidor en la pestaña LAN.
export PuertoServidorMaestro="27017"


# Puerto de Juego Abierto (Visible dentro del Juego)
# - Valores desde 0 hasta 65535
#   * Asegúrese de Abrir el Puerto en UDP y TCP!
export PuertoAbierto="27015"


# Puerto de Autentificación (usado también por B3)
# - Valores desde 0 hasta 65535
#   * Asegúrese de Abrir el Puerto en UDP y TCP!
export PuertoAutentificacion="8766"


# Especificar el Archivo de Configuración del Servidor (que esta dentro de la carpeta "players2")
#   * No olvides editar "Predeterminado.dspl" para especificar mapas y modos de juego.
export CFGServidor="Servidor.cfg"


# Opciones de Lanzamiento
# Añádelos con un espacio, por ejemplo: OpcionesLanzamiento=XXX YYY ZZZ
# -enable_b3          - Activa B3
# -secure_b3          - Añade seguridad al B3
# -enable_rcon        - Activa el Server Rcon (requerido para el B3)
# -no_integrity       - Saltea la verificación SHA-256 de los Mapas
# -enable_slow_motion - Activa la cámara lenta en la cámara de muerte final
export OpcionesLanzamiento="-no_integrity"


# Iniciar la Rotación
# Iniciar la rotación, y, por lo tanto, el servidor.
# No - El servidor se inicia parcialmente (no carga mapa, scripts, etc.)
# Si - El servidor se inicia completamente
export IniciarServidor="Si"


# ---------------- Ignora esto ----------------
case $VisibilidadServidor in
    1)
        export VSD="LAN"
    ;;
    2)
        export VSD="Internet"
    ;;
esac
# ---------------------------------------------
case $IniciarServidor in
    No)
        export IniciarRotacion=
    ;;
    Si)
        export IniciarRotacion=start_map_rotate
    ;;
esac
# ---------------------------------------------


# ---------------------------------------------
# Ignora esto también...
# A menos que sepas lo que estás haciendo.
# ---------------------------------------------
echo ""
echo "//////////////////////////////////////////////"
echo "////                AVISO                 ////"
echo "//////////////////////////////////////////////"
echo ""
echo "Si desea cerrar su Servidor Dedicado:"
echo "1. Cierre esta ventana."
echo "2. Cierre la ventana del servidor."
echo ""
echo ""
echo "//////////////////////////////////////////////"
echo "////              INFO EXTRA              ////"
echo "//////////////////////////////////////////////"
echo ""
echo "- Nombre del Servidor                   : $NombreServidor"
echo "- Visibilidad del Servidor              : $VSD"
echo "- Puerto Seguro de Juego                : $PuertoServidor"
echo "- Puerto del Servidor Maestro           : $PuertoServidorMaestro"
echo "- Puerto de Juego Abierto               : $PuertoAbierto"
echo "- Puerto de Autentificacion             : $PuertoAutentificacion"
echo "- Archivo de Configuracion del Servidor : $CFGServidor"
echo "- Opciones de Lanzamiento               : $OpcionesLanzamiento"
echo "- Iniciar la Rotacion                   : $IniciarServidor"
for (( ; ; ))
do
echo ""
echo ""
echo "---------------------------------------------------------------"
echo "`date +["%d/%m/%Y - %T"]` Iniciando el Servidor Dedicado..."
wine iw5mp_server_wine.exe $OpcionesLanzamiento +set dedicated "$VisibilidadServidor" +set net_ip "$IPServidor" +set net_port "$PuertoServidor" +set net_masterServerPort "$PuertoServidorMaestro" +set net_queryPort "$PuertoAbierto" +set net_authPort "$PuertoAutentificacion" +set sv_config "$CFGServidor" +$IniciarRotacion
echo "`date +["%d/%m/%Y - %T"]` AVISO: El servidor se ha detenido."
echo "`date +["%d/%m/%Y - %T"]` Reiniciando..."
echo "---------------------------------------------------------------"
done
