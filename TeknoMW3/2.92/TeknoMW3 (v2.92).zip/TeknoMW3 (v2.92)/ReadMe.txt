-------------------------------------------------------------------
| TeknoMW3 2.92 - Modern Warfare 3 Steamless/Demonwareless Loader |
|                       www.teknogods.com                         |
-------------------------------------------------------------------


We hope you'll enjoy this fine release! It took months to pull it
off. - We basically had to write some missing pieces of the game,
add a lot of extra services and code to handle them. 

Our goal was to make it easier to play the game on LAN parties
or wherever a proper internet connection is a problem.

For future releases we plan on adding Internet server list,
an in-game console, mod support and much much more!

Don't forget to donate if you would like to keep us supporting
this Modern Warefare 3 MOD!

                                             Regards & Enjoy
                                                   -+-
                                             TeknoGods Staff



                         Requirements:
------------------------------------------------------------------
1. .NET Framework 4.0
   http://www.microsoft.com/download/en/details.aspx?id=17851
2. Original Modern Warfare 3 1.9.446.
3. Original IW5SP.exe.
4. No pirated versions


                           Change Log:
------------------------------------------------------------------
  Current version (2.92):
------------------------------------------------------------------
2.92
 - Still SP only
 - Added support to 1.9.446 that comes with Collection 3.
 - Speed problems should be fixed

------------------------------------------------------------------
  Previous versions:
------------------------------------------------------------------
2.91 
 - Still SP only
 - Added support to 1.9.441

2.9
- Added support to latest DLC Packs and Version 1.9.433.
- Only SP at the moment and only works with version 1.9.433.

2.5:
- Enabled Internet Server List - You can now browse online servers
  Requirements for the server: NAT out the net_masterServerPort in
  order to make your server visible to the clients.
- CPU usage drastically decreased. No more 100% core use.
- Minor stability fixes, more to come soon.

2.4:
- Fixed Windows Server 2003/2008 crash bug (DEP related)
- Minor protocol security improvements
 
2.3:
- Added dedicated server launcher 'TeknoMW3_dedicated.exe' for
  linux(wine)/windows.
- Removed admin requirements from running the loader.
- Added domain support now, you can use IP addresses or domains.
- FOV restricted to 80.
- INI no longer gets written over each time game is ran.

2.2:
- Dedicated servers have now lowered CPU requirements to 1Ghz.

2.1:
- Fixed a bug in Loader where it couldn't read process memory sometimes
- Fixed a bug in loader where it would take IP as Dedicated server port
- Fixed a bug where it would require all game executables to be present.
- Lighter process starting.

2.0:
- Dedicated Servers support
  * You can now start a dedicated server when totally offline.
  * The games are now ranked
  * Support for future DLC maps!
  * Server will be visible on server browser / LAN tab. If you wish to connect
    directly use GUI to setup IP and use F12 in game to connect. (works over
    the internet)
- Multiplayer support
  * You can now play using custom classes
  * Theater works
  * The game works totally offline (No need Steam or Demonware connection)
- Profile dumper support
  * If you copied our release to your MW3 game in the Steam folder, you can now
    import your online Demonware profile to play offline. However it will update
    separately from that point.
    Run multiplayer mode using steam -> Alt+Tab back to desktop -> run teknowm3
    loader -> click Profile dumper
  * Your Steam ID can be automatically obtained and saved to the teknogods.ini

1.3:
- SteamID generation failed with ID "/" when ID was not present and progress
  was not saved. This is now fixed and autodetected.
- Multilanguage problems now fixed, French language works fine.

1.2:
- New advanced patching code to prevent timeouts.
- All IP ranges now work.
- IP Box recoded for better usability.
- Bug that caused Client to die on startup is now fixed.
- .NET 4.0 Problems should now be gone.
- Added FOV (65-120) support under settings.
- Now checks for updates on each startup to keep users up-to-date.
- Added "TeknoGods Coop" over the multiplayer text to make it more clear.
- Lot of small bug fixes on loader.
- Version 1.4 of the game now works properly.
- Fixed "," issues with foreign language Windows.
- Added notice when joining game that makes troubleshooting easier
- Added notice when host and client have same IDs.
- Launcher now requires admin rights in order to run.

Hotfix:
- LAN hosts have now better connectivity





                            Setup:
------------------------------------------------------------------
1. Copy TeknoMW3.exe, TeknoMW3.dll to your game folder.
2. Run TeknoMW3.exe
3. On first run select nickname and fov

                   Usage for Singleplayer Host:
------------------------------------------------------------------
1. Press Singleplayer
2. Press Start as host
3. In game press "TeknoGods Coop" to host


                  Usage for Singleplayer Client:
------------------------------------------------------------------
1. Click Singleplayer
2. Enter IP Address
3. Press Start as client
4. In game click on "TeknoGods Coop" to join


                 Usage for getting Steam profile:
------------------------------------------------------------------
1. See Setup
2. Run Modern Warfare 3 Multiplayer from Steam
3. Press the "profile dumper" button in the TeknoMW3 loader GUI
4. Follow instructions
5. Done!

                             Note:
------------------------------------------------------------------
- This release is not intended for piracy usage!
- You must always use the launcher to run the game.


                            Support:
------------------------------------------------------------------
This release is beta quality. If something breaks, review any
pertinent comments on teknogods.com, then email me as a last resort.
Include all log files and a detailed description of problem and
how to reproduce it.



                        Special thanks:
------------------------------------------------------------------
Testers: Happy, Obso, MG, DinoSuperG, Lisfx, Crazycat, Simon, MWatts
Our community of course! :)








                    End User License Agreement:
------------------------------------------------------------------

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
�AS IS�  AND ANY  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO,  THE IMPLIED  WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR  A  PARTICULAR  PURPOSE  ARE  DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY,OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT  LIMITED TO,  PROCUREMENT  OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED  AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY,  OR TORT  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
ANY WAY OUT  OF THE USE  OF THIS  SOFTWARE,  EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.


                              Creds:
------------------------------------------------------------------
               Smurfette <smurfette@teknogods.com>
                  Reaver <reaver@teknogods.com>
                              Simon
            
               Questions or comments are welcomed!